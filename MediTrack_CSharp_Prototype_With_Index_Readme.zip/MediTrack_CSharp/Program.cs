using MediTrack.Data;
using MediTrack.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
var builder = WebApplication.CreateBuilder(args);
var dbPath = Path.Combine(builder.Environment.ContentRootPath, "meditrack.db");
builder.Services.AddDbContext<ApplicationDbContext>(o => o.UseSqlite($"Data Source={dbPath}"));
builder.Services.AddDefaultIdentity<ApplicationUser>(o => {
 o.SignIn.RequireConfirmedAccount = false; o.Password.RequiredLength = 6;
 o.Password.RequireDigit = false; o.Password.RequireNonAlphanumeric = false;
 o.Password.RequireUppercase = false;
}).AddRoles<IdentityRole>().AddEntityFrameworkStores<ApplicationDbContext>();
builder.Services.AddControllersWithViews(); builder.Services.AddRazorPages();
var app = builder.Build();
using (var scope = app.Services.CreateScope()) {
 var db=scope.ServiceProvider.GetRequiredService<ApplicationDbContext>(); db.Database.EnsureCreated();
 var roles=scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
 foreach(var role in new[]{"Admin","User"}) if(!await roles.RoleExistsAsync(role)) await roles.CreateAsync(new IdentityRole(role));
}
if(!app.Environment.IsDevelopment()){app.UseExceptionHandler("/Home/Error");app.UseHsts();}
app.UseHttpsRedirection(); app.UseStaticFiles(); app.UseRouting(); app.UseAuthentication(); app.UseAuthorization();
app.MapControllerRoute("default","{controller=Home}/{action=Index}/{id?}"); app.MapRazorPages(); app.Run();
