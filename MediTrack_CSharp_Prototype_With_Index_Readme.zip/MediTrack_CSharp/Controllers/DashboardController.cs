using MediTrack.Data; using MediTrack.Models; using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace MediTrack.Controllers;
[Authorize] public class DashboardController:Controller {
 readonly ApplicationDbContext db; readonly UserManager<ApplicationUser> users;
 public DashboardController(ApplicationDbContext d,UserManager<ApplicationUser> u){db=d;users=u;}
 public async Task<IActionResult> Index(){var id=users.GetUserId(User)!;var list=await db.Medicines.Where(m=>m.UserId==id).OrderBy(m=>m.ExpiryDate).ToListAsync();ViewBag.Total=list.Count;ViewBag.Soon=list.Count(m=>m.ExpiryDate.Date>=DateTime.Today&&m.ExpiryDate.Date<=DateTime.Today.AddDays(30));ViewBag.Expired=list.Count(m=>m.ExpiryDate.Date<DateTime.Today);ViewBag.Reminders=list.Count(m=>m.ReminderEnabled);return View(list.Take(6).ToList());}
}
