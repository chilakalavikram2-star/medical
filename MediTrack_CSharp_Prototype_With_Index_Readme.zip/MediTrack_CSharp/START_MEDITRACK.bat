@echo off
title MediTrack C# Prototype
cd /d "%~dp0"
echo ==========================================
echo MediTrack - C# ASP.NET Core Prototype
echo ==========================================
dotnet --list-sdks >nul 2>&1
if errorlevel 1 (
  echo .NET SDK was not found. Install the .NET 8 SDK first.
  echo https://dotnet.microsoft.com/en-us/download/dotnet/8.0
  pause
  exit /b 1
)
echo Restoring required packages...
dotnet restore
if errorlevel 1 ( echo Package restore failed. Check your internet connection and SDK installation. & pause & exit /b 1 )
echo Starting MediTrack...
dotnet run
pause
