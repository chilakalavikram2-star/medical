using MediTrack.Models; using Microsoft.AspNetCore.Identity.EntityFrameworkCore; using Microsoft.EntityFrameworkCore;
namespace MediTrack.Data;
public class ApplicationDbContext : IdentityDbContext<ApplicationUser> {
 public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options){}
 public DbSet<Medicine> Medicines=>Set<Medicine>();
 protected override void OnModelCreating(ModelBuilder b){base.OnModelCreating(b);b.Entity<Medicine>().HasOne(m=>m.User).WithMany(u=>u.Medicines).HasForeignKey(m=>m.UserId).OnDelete(DeleteBehavior.Cascade);}
}
