using System.ComponentModel.DataAnnotations;
namespace MediTrack.Models;
public class Medicine {
 public int Id {get;set;}
 [Required,StringLength(100)] public string Name {get;set;}=string.Empty;
 [StringLength(100)] public string? Dosage {get;set;}
 [Range(0,100000)] public int Quantity {get;set;}
 [StringLength(100)] public string? Frequency {get;set;}
 [DataType(DataType.Date),Display(Name="Start date")] public DateTime StartDate {get;set;}=DateTime.Today;
 [Required,DataType(DataType.Date),Display(Name="Expiry date")] public DateTime ExpiryDate {get;set;}=DateTime.Today.AddMonths(6);
 [DataType(DataType.Time),Display(Name="Reminder time")] public TimeSpan? ReminderTime {get;set;}=new(8,0,0);
 [Display(Name="Reminder enabled")] public bool ReminderEnabled {get;set;}=true;
 [StringLength(500)] public string? Notes {get;set;}
 public DateTime CreatedAt {get;set;}=DateTime.UtcNow;
 public string UserId {get;set;}=string.Empty; public ApplicationUser? User {get;set;}
 public string ExpiryStatus => ExpiryDate.Date<DateTime.Today ? "Expired" : ExpiryDate.Date<=DateTime.Today.AddDays(30) ? "Expiring Soon" : "Valid";
}
