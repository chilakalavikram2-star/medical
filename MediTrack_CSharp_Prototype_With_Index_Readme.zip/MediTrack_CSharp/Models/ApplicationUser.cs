using Microsoft.AspNetCore.Identity;
namespace MediTrack.Models;
public class ApplicationUser : IdentityUser { public string? FullName {get;set;} public ICollection<Medicine> Medicines {get;set;}=new List<Medicine>(); }
