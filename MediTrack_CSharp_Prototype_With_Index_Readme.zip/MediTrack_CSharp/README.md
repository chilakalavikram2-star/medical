# MediTrack — C# Medicine Reminder and Expiry Tracker

This is the C# / ASP.NET Core MVC project. The website's home page is `Views/Home/Index.cshtml` (the ASP.NET equivalent of an index page).

## Run it
1. Install the **.NET 8 SDK for Windows x64**. Download it from: https://dotnet.microsoft.com/en-us/download/dotnet/8.0
2. Extract this ZIP to a normal folder, for example `C:\MediTrack`.
3. Double-click `START_MEDITRACK.bat`. Alternatively, open Command Prompt in this folder and run `dotnet restore`, then `dotnet run`.
4. Keep the terminal window open. When it says `Now listening on: http://localhost:5080`, open that address in your browser.

## Important
A C# web app cannot run just by double-clicking an HTML file. It must be started by ASP.NET Core, which requires the .NET SDK/runtime. The `index.html` file in this ZIP is a guide page; the actual app home page is `Views/Home/Index.cshtml`.

## Included features
- User registration and login
- Medicine add, edit, delete, search, and filtering
- Dashboard counts for total, expired, and expiring-soon medicines
- Expiry status and saved reminder schedule fields
- SQLite persistence and user-specific medicine records

## Prototype limitation
Reminder schedules are stored, but this prototype does not send automatic SMS, email, or push notifications. It is for educational demonstration and is not a medical device.
